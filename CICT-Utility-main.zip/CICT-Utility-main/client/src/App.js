
import { Routes, Route } from 'react-router-dom';
import './App.css';
import Form from './Components/Form'
import Login from './Components/Login'
import { RequireToken } from './Auth';

function App() {
  return (
   <div>
    <h1 className='header'>Optum</h1>
    <div className='dpl-nav__border'/>
       <Routes>
       <Route path="/" element = {<Login/>}/>
       <Route path="/details" element = {
        <RequireToken>
          <Form/>
        </RequireToken>
       }/> 
       </Routes>
    </div>
   
  
  );
}

export default App;
