import styled from "styled-components"

//  export const SmallerTextArea = styled(TextArea)`
//     width: 100%;
//     height: 40px;
//     font-family: sans-serif;
//     margin-top: 2px;
//     margin-bottom: 0px;
//   `;

  export const Container = styled.div`
  margin: auto;
`;
