import React, {useState} from "react";
import { useNavigate } from "react-router";
import {ToastContainer, toast} from 'react-toastify'
import "react-toastify/dist/ReactToastify.css"
import axios from "axios";

const Form = ()=>{
    const [values, setValues] = useState({
        url: "",
        repository: "",
        branch: "",
        language: "",
        linter: "",
        pat:"",
        method:"",
        gate_level:"",
        username:"",
        jenkinsToken:"",
        credentials:""
      })
      const {url,repository,branch,language, linter,pat,method,gate_level,username,jenkinsToken,credentials}= values

  //  const [branches, setBranches]=useState([])

const handleChange = (name) => (event) => {
  let value = event.target.value;
  if(name==="branch"){
    const forbiddenWords=["main","master","prod"];
    const regex = new RegExp(forbiddenWords.join("|"),"gi");
  if(value.match(regex)){
    value="";
    toast.error("Restricted branch name entered")
  }
}
  setValues({ ...values, [name]: value })
}

const handleLanguageChange=(event)=>{
  const selectedlanguage = event.target.value;
  setValues({...values, language: selectedlanguage, linter:""})
}

const handleLinterChange = (event) =>{
const selectedLinter = event.target.value;
setValues({...values, linter: selectedLinter})
}

const clickSubmit = (e)=>{
    e.preventDefault()
    // console.log(values)
    axios.post("http://localhost:8000/form-data",{
      url:url,
      repository:repository,
      branch:branch,
      language:language,
      linter:linter,
      pat:pat,
      method:method,
      gate_level:gate_level,
      username:username,
      jenkinsToken:jenkinsToken,
      credentials:credentials
    })
    .then(function (response){
      console.log("response");
      toast.success("Repository Pulled Successfully")
    })
    .catch(function (error) {
      console.log(error, "error");
      toast.error("Something went wrong")
    });
}
const navigate = useNavigate();

const signOut = () => {
  localStorage.removeItem("temitope");
  navigate("/");
};

const handleNextField = (e) => {
  const enteredUrl = e.target.value;
  if (!enteredUrl.startsWith("https") || !enteredUrl.endsWith(".git")) {
    toast.error("Url should start with https and end with .git")
    e.target.value="";
  }
};

// const handlebranches =(e)=>{
//   e.preventDefault()
//   const new_url = values.url
//   const owner = new_url.split("/")[3]
//   const repo = new_url.split("/")[4].split(".")[0]
//   axios.get(`https://api.github.com/repos/${owner}/${repo}/branches`,{
//     headers: { "Authorization": `Bearer ${values.pat}` }
// })
//   .then(function (response){
//     setBranches(response.data)
//     const branchNames = branches.map(branch => branch.name);
//     console.log(branchNames);
//   })
//   .catch((error)=>{
//     console.log(error)
//   })
// }

const entryform =()=>{
 

const languages =[
  {value: "javascript", label: "Javascript"},
  {value: "python", label: "Python"},
  {value: "java", label: "Java"},
  {value: "scala", label: "Scala"},
  {value: "go", label: "Go"},
]
const linters = {
  javascript :[
    {value:"eslint", label:"ESLint"},
    {value:"prettier", label:"Prettier"}
  ],
  python: [
    {value:"flake8", label:"Flake8"},
    {value:"black", label:"Black"},
    {value:"mypy", label:"MyPy"},
    {value:"pylint", label:"Pylint"},
    {value:"ruff", label:"Ruff"}
  ],
  java:[
    {value:"checkstyle",label:"Checkstyle"},
    {value:"pmd", label:"PMD"}
  ],
  scala:[
    {value:"scala-style", label:"Scala Style"},
    {value:"wart-remover", label:"Wart Remover"}
  ],
  go:[
    {value:"golint", label:"Golint"},
    {value:"gofmt", label:"Gofmt"}
  ]
}
    return(
    <div className="user-details">
             <h2>CI/CT Utility</h2>
        <form>
        <div className="form-group">
        <label htmlFor="url">Github Url </label>
        <input
          type='text'
          value={url}
          onChange={handleChange("url")}
          onBlur={handleNextField}
          placeholder='Enter Github Url'
          style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
        />
        {/* <button 
        onClick={handlebranches}
        style={{maxHeight:'30px', textAlign:'start' , display: 'inline', marginTop:'20px'}}
        >
          Proceed</button> */}
          </div>
          <div className="form-group">
          <label htmlFor="branch">Branch Name</label>
          <input
          type='text'
          value={branch}
          onChange={handleChange("branch")}
          placeholder='Branch Name'
          style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
        />
        </div>
          <div className="form-group">
          <label htmlFor="pat">PAT</label>
          <input
          type="password"
          value={pat}
          onChange={handleChange("pat")}
          placeholder='Enter Personel Access Token'
          style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
        />
        <div className="form-group">
        <label htmlFor="language">Select Language</label>
          <select
          value={language}
          onChange={handleLanguageChange}
          style={{ padding: '5px 15px', width: 434, fontSize: 12, marginBottom: '10px' }}
          >
          <option value="" disabled>Select Language</option>
          {languages.map((lang)=>(
            <option key={lang.value} value={lang.value}>
              {lang.label}
            </option>
          ))}
          </select>
        </div>
        <div className="form-group">
        <label htmlFor="method">Select Method</label>
          <select 
          value={method}
          onChange={handleChange("method")}
          style={{ padding: '5px 15px', width: 434, fontSize: 12, marginBottom: '10px' }}
          >
          <option value="" disabled>Select Method</option>
          <option value="1">Jenkins</option>
          <option value="2">Github Actions</option>
          </select>
        </div>
        {method === "1" && (
  <div className="form-group">
    <label htmlFor="username">Jenkins Username</label>
    <input
      type="text"
      value={username}
      onChange={handleChange("username")}
      placeholder="Enter Username"
      style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
    />
  </div>
)}
{method === "1" && (
  <div className="form-group">
    <label htmlFor="jenkinsToken">Jenkins API Token</label>
    <input
      type="password"
      value={jenkinsToken}
      onChange={handleChange("jenkinsToken")}
      placeholder="Enter Jenkins Token"
      style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
    />
  </div>
)}
{method === "1" && (
  <div className="form-group">
    <label htmlFor="credentials">Credentials</label>
    <input
      type="password"
      value={credentials}
      onChange={handleChange("credentials")}
      placeholder="Enter Jenkins Credentails"
      style={{ padding: '5px 15px', width: 400, fontSize: 12, marginBottom: '10px' }}
    />
  </div>
)}
        <div className="form-group">
        <label htmlFor="linter">Select Linter</label>
          <select
          value={linter}
          onChange={handleLinterChange}
          style={{ padding: '5px 15px', width: 434, fontSize: 12, marginBottom: '10px' }}
          >
            <option value="" disabled>Select Linter</option>
            {linters[language]?.map((linter)=>(
              <option key={linter.value} value={linter.value}>
               {linter.label}
              </option>
            ))}
          </select>
        </div>

          </div>
          <button className="submit-button" type="submit" onClick={clickSubmit}
          disabled={!url}
          >
            <strong>Submit</strong>  
          </button>
          <button onClick={signOut}><strong>Sign out</strong></button>
        </form>
    </div>
    )
}
return (
    <>
    <div>
    <ToastContainer position="top-right" autoClose={3000} hideProgressBar={true}/>
    {entryform()}
    </div>
    </>
)
}
export default Form
