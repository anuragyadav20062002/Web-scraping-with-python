import { useNavigate } from "react-router-dom";
import { fetchToken, setToken } from "../Auth";
import { useState } from "react";
import axios from "axios";
import {ToastContainer, toast} from 'react-toastify'
import "react-toastify/dist/ReactToastify.css"

export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  //check to see if the fields are not empty
  const login = event => {
    event.preventDefault();
    if ((username === "") & (password === "")) {
      return;
    } else {
      axios
        .post("http://localhost:8000/", {
          username: username,
          password: password,
        })
        .then(function (response) {
          console.log(response.data.token, "response.data.token");
          if (response.data.token) {
            setToken(response.data.token);
            navigate("/details");
            toast.success("Successfully Logged In")
          }
        })
        .catch(function (error) {
          console.log(error, "error");
          toast.error(error)
        });
    }
  };


  return (
    <div style={{ minHeight: 800, marginTop: 30}} className="user-details">
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar={true}/>
      <h1>Login</h1>
      <div style={{ marginTop: 30 }}>
        {fetchToken() ? (
          <p>Logged In</p>
          
        ) : (
          <div>
            <form>
              <div style={{marginBottom: 10}}>
              <label style={{ marginRight: 10 }}>Username</label>
              <input
                type="text"
                onChange={(e) => setUsername(e.target.value)}
                style={{ padding: '5px 15px', width: 150, fontSize: 12, marginBottom: '10px' }}
              />
              </div>

              <div style={{marginBottom: 10}}>
              <label style={{ marginRight: 10 }}>Password</label>
              <input
                type="password"
                onChange={(e) => setPassword(e.target.value)}
                style={{ padding: '5px 15px', width: 150, fontSize: 12, marginBottom: '10px' }}
              />
              </div>  
              <button className="button-submit" onClick={login} 
               >
                <strong>
                Submit
                </strong>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

