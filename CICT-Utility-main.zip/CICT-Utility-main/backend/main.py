import shutil
from fastapi import FastAPI
from pydantic import BaseModel
import jwt
import subprocess
import re
import os
from pydantic import BaseModel
from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from fastapi import Request
import requests
import time

SECERT_KEY = "YOUR_FAST_API_SECRET_KEY"
ALGORITHM ="HS256"
ACCESS_TOKEN_EXPIRES_MINUTES = 800

test_user = {
   "username": "cicdadmin",
   "password": "cicdpassword",

}

app = FastAPI()

origins = {
    "http://localhost",
    "http://localhost:3002",
}

app.add_middleware(
   CORSMiddleware,
    allow_origins = origins,
    allow_credentials =False,
    allow_methods = ["*"],
    allow_headers= ["*"],
)

class LoginItem(BaseModel):
   username: str
   password: str

   @app.get("/")
   def read_root():
      return {"Hello": "World"}


@app.post("/")
async def user_login(loginitem:LoginItem):
    data = jsonable_encoder(loginitem)
    if data['username']== test_user['username'] and data['password']== test_user['password']:
        encoded_jwt = jwt.encode(data, SECERT_KEY, algorithm=ALGORITHM)
        return {"token": encoded_jwt}
    else:
        return {"message":"login failed"}
    
@app.post("/form-data")
async def receive_form_data(form_data: dict):
    url = form_data['url']
    repo_name = form_data['repository']
    branch = form_data['branch']
    pat = form_data['pat']
    method = form_data['method']
    language = form_data['language']
    linter = form_data['linter']
    username = form_data['username']
    jenkinsToken = form_data['jenkinsToken']
    credentials = form_data['credentials']
    

    #method = method.lower()
    #language = language.lower()
    output = dict()

    repo_name = url.split("/")[4].split(".")[0]
    print("repo_name", repo_name)

    # Checking if the workspace folder exists and creating it if it doesn't
    backend_path = os.getcwd()
    parent_path = os.path.abspath(os.path.join(backend_path, os.pardir))
    workspace_path = os.path.join(parent_path,"workspace")
    
    if not os.path.exists(workspace_path) :
        os.mkdir(workspace_path)

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    output['Workspace Path'] = workspace_path
    output['Backend Path'] = backend_path
    output['Parent Path'] = parent_path

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#


    # Write constraints
    # pat token
    # git format, form a string with https://pattoken@uri
    # Checking if the URL starts with https:// and ends with •git using regular expressions 
    if not re.match('^https://.*\.git$', url):
        url = f'https://{url}.git'
        #Combining the URL and PAT using regular expressions
    url_with_pat = re.sub('^https://', f'https://{pat}@', url)
    print("URL WITH PAT: "+url_with_pat)
    print()
    print()

    #-------------------------------------------------------------------------------------#
    output['URL WITH PAT'] = url_with_pat
    #-------------------------------------------------------------------------------------#
    clone = True

    try:
    # Cloning the repository inside the workspace folder
        os.chdir(workspace_path)
        subprocess.run(["git","clone",'--branch',branch, url_with_pat])
        print(".Cloned Successfully")
    except:
        print("Clone Failed!")
        clone = False

    print()
    print()

    output['Clone'] = clone


    repo_path = os.path.join(workspace_path, repo_name) 
    #os.chdir(repo_path) 
    os.chdir(repo_path)
    try:
        stdout = subprocess.run(["git","branch","-a"],check=True,capture_output=True,text=True).stdout
        print('---------')
    except:
        print("Git Branch List Failed!")

    #Filtering branch names from output
    branchNotFound = False
    try:
        ls = stdout.replace(" ",'').split('\n')
        ls = [l for l in ls if l[0:7]=='remotes']
        ls = [l for l in ls if l.count('HEAD')==0]
        ls = [l[l.rfind("/")+1:] for l in ls]
        print('------------------------------')
        print(ls)
        print('==============================')
    except:
        print('Error!')
    
    #Searching for required branch
    if branch not in ls:
        branchNotFound=True

    output['Branches'] = ls
    output['Branch not found'] = branchNotFound
        
    print()
    print()
    print()

    output['Repository Path'] = repo_path

    print("Repository Path: "+repo_path)
    print("Current Working Directory: "+os.getcwd())
    print("Parent Path: "+parent_path)


    # making workflow directory 
    
    github_path= os.path.join(repo_path,".github")
    
    if not os.path.exists(github_path):
       os.mkdir(github_path)
    
       
    workflow_path = os.path.join(github_path,"workflows")
    
    if not os.path.exists(workflow_path):
        os.mkdir(workflow_path)

    #copying linter file in workflows
    linter_source= os.path.join(parent_path,"template","linter",f"{linter}.yml")
    linter_destination= os.path.join(workflow_path,f"{linter}.yml")
    
    try:
        shutil.copyfile(linter_source,linter_destination)
        print("Linter File Copied successfully")
    except:
        print("Linter file not copied")
    
    
    #copying pull_request_validator.yml in workflows
    linter_source= os.path.join(parent_path,"template","linter","pull_request_validator.yml")
    linter_destination= os.path.join(workflow_path,"PullRequestTemplateValidator.yml")
    try:
        shutil.copyfile(linter_source,linter_destination)
        print("Pull Request template validator file Copied successfully")
    except:
        print("Pull Request template validator not copied")
      
    #copying xray in workflows
    #linter_source= os.path.join(parent_path,"template","linter","xray.yml")
    #linter_destination= os.path.join(workflow_path,"XrayScan.yml")
    #try:
        #shutil.copyfile(linter_source,linter_destination)
        #print("Xray file Copied successfully")
    #except:
        #print("Xray file not copied")

    #copying codeQL in workflows
    linter_source= os.path.join(parent_path,"template","linter","codeQL.yml")
    linter_destination= os.path.join(workflow_path,"CodeQl.yml")
    try:
        shutil.copyfile(linter_source,linter_destination)
        print("CodeQl Copied successfully")
    except:
        print("CodeQl file not copied")
      
    
    
    # copying pull-request-template in .github folder
    
    prt_source= os.path.join(parent_path,"template","pr_template","PULL_REQUEST_TEMPLATE.md")
    prt_destination= os.path.join(github_path,"PullRequestTemplate.md")
    
    try:
      shutil.copyfile(prt_source,prt_destination)
      print("Pull request file copied successfully")
    except:
      print("Can't copy Pull request template file")

    # copying labeler file in .github folder
    prt_source= os.path.join(parent_path,"template","pr_template","labeler.yml")
    prt_destination= os.path.join(github_path,"labeler.yml")
    
    try:
      shutil.copyfile(prt_source,prt_destination)
      print("Labeler file copied successfully")
    except:
      print("Can't copy labeler file")

  


   # copying sonar.properties
    sonar_prop_path=os.path.join(repo_path,"sonar-project.properties")
    sonar_prop_content = f"""sonar.projectKey=com.optum.ipa:{repo_name}
sonar.projectName={repo_name}
sonar.python.version=3.10, 3.11"""
    with open(sonar_prop_path, "w") as f:
     f.write(sonar_prop_content)


    # copying Jenkinsfile/Github_Action files

    if method == '1':
      # Specify the source and destination paths
      jenkinsfile_source = os.path.join(parent_path, "template", "jenkins", f"{language}")
      jenkinsfile_destination = os.path.join(repo_path, "ci-ct.jenkinsfile")

         #Copying the Jenkinsfile to the cloned repository with renaming
      try:
        shutil.copyfile(jenkinsfile_source, jenkinsfile_destination)
        print("Jenkinsfile copied successfully!")
      except Exception as e:
        print(f"Failed to copy Jenkinsfile: {str(e)}")
        
    elif method =='2':
        githubaction_source = os.path.join(parent_path,"template","github actions",f"{language}.yml")
        print("***")
        githubaction_destination= os.path.join(repo_path,".github","workflows","CICTPipeline.yml")
        print("****")
        
    #Copying the github_actions file to the cloned repository with renaming
        
        try:
            shutil.copyfile(githubaction_source,githubaction_destination)
            print("Github Action File Copied Successfully")
        except:
            print("Failed to copy github_actions file")
        

    #subprocess.run(["git","-C","add",parent_path+"\\template\\jenkins\\python.txt","."])
    #subprocess.run(['git','mv','java.txt',repo_path],cwd=parent_path+'\template\jenkins')
    
    os.chdir(repo_path)
    print()
    print()

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    try:
        subprocess.run(['git','add','.'])#,cwd=repo_path)
        print("Added")
        output['Git Add'] = True
    except:
        print("Error - add failed!")
        output['Git Add'] = False
    print()
    print()

    

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#


    try:
        commit_message = "Commitmessage" 
        subprocess.run(["git","commit","-m" ,commit_message])#, cwd=workspace_path)
        print("Committed")
        output['Git Commit'] = True
    except: 
        print("Error - Commit failed!")
        output['Git Commit'] = False
    print()
    print()

    
    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    try:
        #subprocess.run(['git','remote','add','origin',url])
        subprocess.run(['git','remote','-v'])
    except:
        print("Remote Add Failed!!")
    print()
    print()

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    try:
        br = "github_workflows"
        subprocess.run(["git","checkout","-b",br])
        output['Git New Branch'] = True
    except:
        print('Checkout failed!')
        output['Git New Branch'] = False
    print()
    print()

    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    try:
        subprocess.run(['git','push','-f','origin',br])#, cwd=workspace_path)
        print(".....")
        output['Git Push'] = True
    except:
        print("Error - push failed!")
        output['Git Push'] = False
    print()
    print()
    
    #-------------------------------------------------------------------------------------#
    #-------------------------------------------------------------------------------------#

    try:
        cmd = 'origin/main'+'...'+'origin/'+branch
        subprocess.run(["git","rev-list",'--left-right','--count',cmd])
        print()
        print('*'*40)
        print()
        cmd2 = 'main...'+branch
        stdout = subprocess.run(["git","rev-list",'--left-right','--pretty=oneline',cmd2],check=True,capture_output=True,text=True).stdout
        print(stdout)
        print('-'*40)

    except:
        print("Status Error!") #server throws error until PR is open
        


  #Triggering jenkins only when PR is open
    os.chdir(backend_path)
    pullreq = False
    if method =='1':
       gurl = url
       branch = "github_workflows"
       spath = "ci-ct.jenkinsfile"
       job_name = "multibranch"
       cred = credentials
       jenkins_url = "https://jenkins-paasopsapi.optum.com"
       username = username
       password = jenkinsToken
       auth = (username,password)
       cfg = f'''<?xml version='1.1' encoding='UTF-8'?>
       <org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject plugin="workflow-multibranch@2.21">
        <actions/>
        <description></description>
        <displayName>{job_name}</displayName>
        <properties>
          <org.jenkinsci.plugins.pipeline.modeldefinition.config.FolderConfig plugin="pipeline-model-definition@1.5.0">
            <dockerLabel></dockerLabel>
            <registry plugin="docker-commons@1.16"/>
          </org.jenkinsci.plugins.pipeline.modeldefinition.config.FolderConfig>
        </properties>
        <folderViews class="jenkins.branch.MultiBranchProjectViewHolder" plugin="branch-api@2.5.5">
          <owner class="org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject" reference="../.."/>
        </folderViews>
        <healthMetrics>
          <com.cloudbees.hudson.plugins.folder.health.WorstChildHealthMetric plugin="cloudbees-folder@6.11">
            <nonRecursive>false</nonRecursive>
          </com.cloudbees.hudson.plugins.folder.health.WorstChildHealthMetric>
        </healthMetrics>
        <icon class="jenkins.branch.MetadataActionFolderIcon" plugin="branch-api@2.5.5">
          <owner class="org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject" reference="../.."/>
        </icon>
        <orphanedItemStrategy class="com.cloudbees.hudson.plugins.folder.computed.DefaultOrphanedItemStrategy" plugin="cloudbees-folder@6.11">
          <pruneDeadBranches>true</pruneDeadBranches>
          <daysToKeep>-1</daysToKeep>
          <numToKeep>-1</numToKeep>
        </orphanedItemStrategy>
        <triggers>
        </triggers>
        <disabled>false</disabled>
        <sources class="jenkins.branch.MultiBranchProject$BranchSourceList" plugin="branch-api@2.5.5">
          <data>
            <jenkins.branch.BranchSource>
              <source class="jenkins.plugins.git.GitSCMSource" plugin="git@4.0.0">
                <id>2a79f6e5-914b-4c53-880b-6b7baf1297rc</id>
                <remote>{gurl}</remote>
                <credentialsId>{cred}</credentialsId>
                <traits>
                  <jenkins.plugins.git.traits.BranchDiscoveryTrait/>
                  <jenkins.plugins.git.traits.CloneOptionTrait>
                    <extension class="hudson.plugins.git.extensions.impl.CloneOption">
                      <shallow>false</shallow>
                      <noTags>false</noTags>
                      <reference></reference>
                      <honorRefspec>false</honorRefspec>
                    </extension>
                  </jenkins.plugins.git.traits.CloneOptionTrait>
                </traits>
              </source>
              <strategy class="jenkins.branch.DefaultBranchPropertyStrategy">
                <properties class="empty-list"/>
              </strategy>
              <buildStrategies>
                <jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl plugin="basic-branch-build-strategies@1.3.2">
                  <filters>
                    <jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-ExactNameFilter>
                      <name>{branch}</name>
                      <caseSensitive>false</caseSensitive>
                    </jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-ExactNameFilter>
                    <jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-RegexNameFilter>
                      <regex>^.*$</regex>
                      <caseSensitive>false</caseSensitive>
                    </jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-RegexNameFilter>
                  </filters>
                </jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl>
              </buildStrategies>
            </jenkins.branch.BranchSource>
          </data>
          <owner class="org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject" reference="../.."/>
        </sources>
        <factory class="org.jenkinsci.plugins.workflow.multibranch.WorkflowBranchProjectFactory">
          <owner class="org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject" reference="../.."/>
          <scriptPath>{spath}</scriptPath>
        </factory>
      </org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject>'''
       callJenkins(pullreq,cfg,jenkins_url,auth,job_name,url,pat,branch)
    elif method=='github actions':
     print("Coming soon")
    output['Message'] = "Form Data Recieved Successfully"    
   
    return output



if __name__ == "__main__":
    uvicorn.run("main:app",host="127.0.0.1",port=8000,log_level="info")

    
#-----------------------------------------------------------------------------------#


#Creating and triggering jenkins job

def create_job(data,jenkins_url,auth,job_name):
    #auth = (username, password)
    headers = {'Content-Type': 'application/xml'}
    response = requests.post(jenkins_url+'/job/ci-ct' + '/createItem', auth=auth, headers=headers, params={'name': job_name}, data=data, verify=False)
    response.raise_for_status()
    print(f"Multibranch job '{job_name}' created successfully!")

def trigger_job(jenkins_url,auth,job_name):
    build_url = f'{jenkins_url}/job/ci-ct/job/{job_name}/build'
    response = requests.post(build_url, auth=auth, verify=False)
    response.raise_for_status()
    print(f"Jenkins job '{job_name}' triggered successfully!")

def scanBranchOutput(jenkins_url,auth,job_name):
    res = requests.get(f'{jenkins_url}/job/ci-ct/job/{job_name}/indexing/consoleText',auth=auth,verify=False)
    return res.content

def get_build_counts(jenkins_url,auth,job_name):
    jenkins_url = 'https://jenkins-paasopsapi.optum.com'
    job_api = f'{jenkins_url}/job/ci-ct/job/{job_name}/api/json?tree=jobs[name,lastBuild[number]]'
    response = requests.get(job_api,auth=auth,verify=False)
    if response.status_code == 200:
        build_counts = {}
        data = response.json()
        for job in data['jobs']:
            branch_name = job['name']
            build_count = job['lastBuild']['number']
            build_counts[branch_name] = build_count
    else:
        print(f'Failed to retrieve build counts for {job_name}. Status code: {response.status_code}')
    for branch_name, build_count in build_counts.items():
        print(f'Branch: {branch_name}, Build Count: {build_count}')



def get_pull_requests_with_branches(owner, repo, t):
    # Defining the GitHub API endpoint URL for pull requests
    headers = {'Authorization': f'token {t}'}
    api_url = f'https://api.github.com/repos/{owner}/{repo}/pulls'


    # Sending API request to retrieve pull requests
    
    response = requests.get(api_url, headers = headers)

    if response.status_code == 200:
        # Extracting pull requests and their branches
        pull_requests = response.json()
        pull_requests_with_branches = []
        for pull_request in pull_requests:
            branches = get_pull_request_branches(owner, repo, t, pull_request['number'])
            pull_requests_with_branches.append((pull_request, branches))

        return pull_requests_with_branches
    else:
        print(f'Failed to retrieve pull requests. Status code: {response.status_code}')
        return []

def get_pull_request_branches(owner, repo, t , pull_request_number):
    # Defining the GitHub API endpoint URL for pull request details
    headers = {'Authorization': f'token {t}'}
    api_url = f'https://api.github.com/repos/{owner}/{repo}/pulls/{pull_request_number}'

    # Sending API request to retrieve pull request details
    response = requests.get(api_url, headers = headers)

    if response.status_code == 200:
        # Extracting branches from the pull request details
        pull_request_details = response.json()
        branches = {
            'base': pull_request_details['base']['ref'],
            'head': pull_request_details['head']['ref']
        }
        return branches
    else:
        print(f'Failed to retrieve pull request details. Status code: {response.status_code}')
        return {}

def callJenkins(pullreq,cfg,urljenkins,authenticate,jobname,giturl,pat,branch):
    giturl = giturl.replace("https://github.com/","").replace(".git","")
    owner = giturl.split('/')[0]
    repo = giturl.split('/')[1]
    while(pullreq==False):
        time.sleep(2) #wait for 2 seconds
        pull_requests_with_branches = get_pull_requests_with_branches(owner, repo, pat)
        for pull_request, branches in pull_requests_with_branches:
            if branches['base'] == branch or branches['head'] == branch:
                pullreq = True
                print(f'Pull Request: #{pull_request["number"]} - {pull_request["title"]}')
                print(f'Base: {branches["base"]}')
                print(f'Head: {branches["head"]}')
    if pullreq==True:
      create_job(cfg,urljenkins,authenticate,jobname)
      trigger_job(urljenkins,authenticate,jobname)
      get_build_counts(urljenkins,authenticate,jobname)





    
  

    



