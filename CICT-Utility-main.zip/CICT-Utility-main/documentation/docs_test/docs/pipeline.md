# 4. Pipelines

<h1><strong>GitHub Actions</strong></h1>

<h2>Overview</h2>

<p>GitHub Actions is a powerful platform provided by GitHub that allows users to automate various workflows in their repositories. It provides a wide range of pre-built actions and allows custom actions to be defined.</p>

<h2>Pull request template</h2>

<p>A review template is a predefined set of instructions and guidelines used during code reviews, pull request reviews, or any other review process in software development. It typically exists as a Markdown (.md) file and is placed in the `.github` folder (specific to GitHub) within a project repository. The review template helps streamline the review process, ensuring consistency, clarity, and completeness in evaluating code changes or other work items. It can be triggered automatically when a new pull request is created, guiding reviewers through the assessment of the changes.</p>

<h2>Specifications of a review template in the `.github` folder:</h2>

<ul>
<li>File Location: The review template file should be placed in the `.github` directory of the repository to ensure it is automatically recognized by GitHub for pull request reviews.
<li>Filename: The file should have a specific filename to be recognized by GitHub. For pull request templates, the recommended filename is `PULL_REQUEST_TEMPLATE.md`.
<li>Markdown Format: Use Markdown formatting to structure the template effectively. Markdown allows for headings, lists, checkboxes, and other formatting elements that enhance readability.
<li>Sections and Guidelines: Organize the template into sections, each focusing on different aspects of the review process. Include guidelines, checklists, and instructions to help reviewers understand what to look for.
<li>Triggering: The review template is automatically triggered when someone creates a new pull request. GitHub will display the contents of the template in the pull request description, guiding the submitter and reviewers through the necessary steps.
<li>Customization: Tailor the template to match the specific requirements and development practices of the team or project.
<li>Version Control: Like any other code or documentation, keep the review template under version control to track changes and updates over time.
<li>Reviewers and Contributors: Encourage reviewers and contributors to provide feedback on the review template to improve its effectiveness.
</ul>

<h2>Points to remember when creating a review template:</h2>
<ul>
<li>Clarity: Use clear and concise language to ensure that reviewers understand what is expected of them during the review.
<li>Completeness: Include all necessary sections to cover the essential aspects of the review, such as code quality, functionality, testing, documentation, and references.
<li>Flexibility: While providing guidelines, allow some flexibility to accommodate different types of changes and projects.
<li>Alignment with Team Practices: Ensure that the review template aligns with the team's established development and review processes.
<li>Encourage Collaboration: The template should facilitate productive discussions between reviewers and contributors rather than being a rigid checklist.
<li>Keep it Updated: Periodically review and update the template to reflect changes in the team's practices or lessons learned from previous reviews.
</ul>

<h2>Pull request template- Validator</h2>
<p>
The Template Validator is an automation tool designed to validate the contents of the review template used in pull requests. It ensures that the template adheres to specific requirements and guidelines, promoting consistency and completeness in the review process. This GitHub Actions workflow runs automatically whenever a pull request is assigned, opened, synchronized, or reopened, as well as when a pull request review is edited or dismissed.
</p>

<h3>Trigger Events</h3>
The Template Validator is triggered by the following GitHub Actions events:
<ul>
<li> pull_request: Triggered on pull request actions, including assigned, opened, synchronize (when a new commit is pushed), and reopened events.
<li> pull_request_review: Triggered when a pull request review is edited or dismissed.
</ul>

<h3>Validation Rules</h3>
The Template Validator enforces the following validation rules on the review template:
<ul>
<li> Reviewer Section Validation (rule-1): Checks if at least one block is ticked in the reviewer section. The presence of a tick ([x]) indicates that the corresponding review criterion has been addressed.
<li> Code Changes Validation (rule-2): Verifies that valid code changes are added in the "Changes" section of the template. The validator checks for the presence of the placeholder text "Put relevant code changes here."
<li> References Validation (rule-3): Ensures that the "References" section contains valid links in the format of "https://domain.com/user/repo" or similar.
<li> Screenshots Validation (rule-4): Checks if there are screenshots included in the "Screenshots" section. It looks for the Markdown image format `![Alt Text](URL)`.
</ul>

<h3>Usage</h3>
The Template Validator is implemented as a GitHub Actions workflow, defined in the `.github/workflows/template_validator.yml` file of the repository. The workflow consists of the following steps:
<ul>
<li> Checkout Repository: Checks out the repository to access its contents.
<li> Set up Node.js: Sets up the Node.js environment (version 14) required for executing JavaScript scripts.
<li> Install Dependencies: Installs the necessary dependencies using npm.
<li> Read File: Reads the content of the review template file (`.github/PULL_REQUEST_TEMPLATE.md`).
<li> Rule-1: Validates the reviewer section to ensure at least one block is ticked ([x]).
<li> Rule-2: Checks for the presence of valid code changes in the "Changes" section.
<li> Rule-3: Validates the "References" section for the presence of valid links.
<li> Rule-4: Checks if there are screenshots included in the "Screenshots" section.
</ul>

<h3>Customization</h3>
To customize the Template Validator for your project, you can modify the validation rules, add additional checks, or adjust the file paths if your review template is stored in a different location. The workflow file (`template_validator.yml`) can be edited directly in the `.github/workflows` directory of your repository.
Please note that the validation rules should align with your team's specific requirements and review practices. Regularly review and update the template validator to accommodate any changes in the review template or project guidelines.



<h2>CI-CT Pipeline</h2>
The CI-CT (Continuous Integration and Continuous Testing) Pipeline is an automated GitHub Actions workflow that ensures code quality, performs unit testing, conducts SonarQube static code analysis, and enforces pull request size limits for a repository. The workflow is triggered on pull requests for any branch.

Workflow Overview
<ul>
<li> Trigger: The workflow is triggered automatically whenever a new pull request is opened.
<li> Jobs: The workflow consists of the following jobs:
   - Build_Unit-tests_Sonar-scan: This job executes the entire CI-CT pipeline.
</ul>
 Job: Build_Unit-tests_Sonar-scan
 <ul>
Steps:
<li> Checkout repository: The workflow starts by checking out the repository to access its contents.
<li> Set up Python: Sets up the Python environment with version 3.x for executing Python scripts.
<li> Install dependencies: Installs the required dependencies from the `requirements.txt` file, including `pytest`, `pylint`, and `flake8`.
<li> Triage: Utilizes the GitHub Labeler Action to automatically add labels based on specific conditions.
<li> Size-label: Uses a custom action to add a size label (`XS`, `S`, `M`, or `Too Large`) to the pull request based on the number of lines changed.
<li> Run unit tests: Executes unit tests using `pytest` and generates a code coverage report in XML format (`coverage.xml`).
<li> Calculate pull request size: Calculates the number of lines changed in the pull request compared to the base branch (`main`). The result is stored in the `PR_SIZE` environment variable and GitHub environment.
<li> Check pull request size: Compares the calculated pull request size against a predefined threshold (e.g., 500 lines of code changed). If the size exceeds the threshold, a warning comment is left on the pull request, suggesting splitting the changes into smaller pull requests. The code coverage results are also commented on the pull request.
<li> Perform Sonar Scan: Executes SonarQube analysis using the `optum-eeps/epl-actions/sonar-scan` action. The SonarQube token is provided through a secret (`SONAR_TOKEN`).
<li> SonarQube analysis: Executes SonarQube static code analysis using the `uhg-actions/sonarqube-scan-action` action. Several analysis parameters are specified, including exclusions and test inclusions.
<li> SonarQube Quality Gate check: Checks the SonarQube Quality Gate status to determine whether the analysis meets the defined quality criteria. This step also includes a timeout to fail the workflow if the check takes too long.
<li> SonarQube Quality Gate Status: Displays the Quality Gate status of the SonarQube analysis as an output.
</ul>

<h3>Customization</h3>
To customize the CI-CT Pipeline for your project, consider the following aspects:
<ul>
<li>	Dependency Installation: Adjust the `requirements.txt` file to include project-specific dependencies.
<li>	Unit Testing: Modify the `pytest` command in the "Run unit tests" step to accommodate your test suite structure.
<li>	Pull Request Size Threshold: Change the threshold value in the "Check pull request size" step to match your preferred limit.
<li>	SonarQube Analysis Settings: Adjust the SonarQube analysis parameters in the "SonarQube analysis" step to match your project's requirements.
</ul>


<h3>Labeler</h3>
Triage Labeler
Functionality: The Triage Labeler is a GitHub Actions tool used to automatically apply labels to issues or pull requests based on specific conditions defined in the label configuration. It streamlines the process of categorizing and prioritizing incoming issues or pull requests, helping the development team efficiently manage their workload.
Implementation: In the CI-CT workflow, the Triage Labeler is utilized to add labels like "Bug," "Feature," or "Enhancement" to pull requests based on certain keywords or patterns found in the pull request title or body. This automation assists developers in quickly identifying the nature of each pull request and addressing them accordingly.

<h2>
Size Labels
</h2>
<p>Functionality: The Size Labels are used to automatically categorize pull requests based on the number of lines changed in the pull request compared to the base branch (e.g., `main`). It helps identify the size of each pull request, making it easier to manage larger changes and promoting the use of smaller, more manageable pull requests.</p>

<p>Implementation: In the CI-CT workflow, the Size Labels are integrated to calculate the size of each pull request based on the lines of code changed. Depending on the size, pull requests are categorized as "XS," "S," "M," or "Too Large." This allows the team to focus on reviewing smaller pull requests more efficiently.</p>

<p>Separating Label Configurations into `labeler.yml`
To keep the label configurations organized and maintainable, you can separate them into a `labeler.yml` configuration file placed in the `.github` directory. This approach allows you to have a dedicated file for defining customized labels and their corresponding conditions.



<h2>
Unit tests
</h2>
Unit testing is a fundamental practice in software development, where individual units or components of code are tested to ensure they function correctly and produce the expected results. A unit represents the smallest testable part of an application, such as a function, method, or class. The main goal of unit testing is to validate that each unit of the code works as intended in isolation, independently of other parts of the application.

<h2>
Here are the key points to understand about unit testing:
</h2>
<ul>
<li> Testing in Isolation: During unit testing, the unit being tested is isolated from the rest of the application. This means that any external dependencies, such as databases, APIs, or file systems, are replaced with mock objects or stubs, allowing the unit to be tested in a controlled environment.
<li> Automated Testing: Unit testing is automated, meaning it can be executed automatically as part of the development workflow. Developers write test cases using testing frameworks and libraries specific to the programming language they are using.
<li> Fast Execution: Unit tests are typically designed to execute quickly. Since they focus on small, isolated units, they can run much faster than other types of tests like integration tests or end-to-end tests.
<li> Coverage: Unit tests aim to achieve high code coverage, which means testing as many code paths and scenarios as possible within the unit. Code coverage metrics help measure the percentage of code exercised by unit tests.
<li> Regression Detection: Unit tests play a crucial role in identifying regressions. When new code is added or existing code is modified, running unit tests helps ensure that the changes do not introduce unintended side effects or break existing functionality.
<li> Debugging Aid: When a unit test fails, it provides valuable information about the source of the problem. Developers can use the failing test as a starting point for debugging and fixing the issue.
<li> Continuous Integration (CI) Pipeline: Unit tests are commonly integrated into a CI pipeline. Whenever code changes are pushed or pull requests are submitted, the CI system runs the unit tests to validate the changes before merging them into the main codebase.
<li> Test-Driven Development (TDD): TDD is a development approach in which developers write unit tests before implementing the actual code. This process helps ensure that the code meets the requirements defined by the tests and encourages developers to focus on the desired functionality.
<li> Frameworks and Libraries: Various programming languages have dedicated unit testing frameworks and libraries, such as JUnit for Java, pytest for Python, NUnit for .NET, and Mocha for JavaScript.

Unit testing is an essential practice for building reliable, maintainable, and robust software. By validating the individual units of code in isolation, developers gain confidence in the correctness of their code and can catch defects early in the development process, leading to higher-quality software.

<h2>Sonar Qube</h2>
SonarQube, commonly referred to as Sonar, is an open-source platform for continuous code quality inspection and static code analysis. It helps developers and teams maintain code quality, identify code smells, detect bugs, security vulnerabilities, and enforce coding standards. SonarQube is widely used in software development to ensure the long-term maintainability and reliability of codebases.

<h3>Key features and aspects of SonarQube:</h3>

<ul>
<li> Static Code Analysis: SonarQube performs static code analysis, meaning it analyzes the source code without executing it. The analysis checks for potential issues, such as code smells, bugs, security vulnerabilities, and compliance with coding standards.
<li> Continuous Inspection: SonarQube supports continuous inspection, which means it can be integrated into the continuous integration (CI) and continuous delivery (CD) pipelines. It automatically scans code whenever changes are pushed or pull requests are created, providing immediate feedback to developers.
<li> Rule-Based Analysis: SonarQube employs a rule-based system where developers can define custom rules or use predefined rules provided by SonarQube. These rules are used to evaluate code against best practices and coding standards.
<li> Quality Gates: SonarQube allows the definition of quality gates, which are sets of predefined conditions that code must meet to be considered of acceptable quality. Quality gates can be used to block merges or deployments if code quality does not meet the defined criteria.
<li> Dashboard and Reports: SonarQube provides a web-based dashboard and reports that display the results of the code analysis. The dashboard summarizes code quality metrics, issues, and trends over time.
<li> Languages and Ecosystems: SonarQube supports a wide range of programming languages, including Java, JavaScript, Python, C/C++, C#, TypeScript, and more. Additionally, it integrates with popular build tools and CI/CD systems like Jenkins, GitLab CI, and Azure DevOps.
<li> Code Smells and Technical Debt: SonarQube identifies code smells, which are indicators of potential design or implementation issues that might lead to maintenance problems. It also calculates technical debt based on the severity of detected issues.
<li> Security Vulnerabilities: SonarQube includes security rulesets that help identify and mitigate common security vulnerabilities, such as SQL injection, cross-site scripting (XSS), and insecure cryptographic algorithms.
<li> Customizability: SonarQube can be customized to fit specific project requirements. Teams can enable or disable rules, adjust severity levels, and define their own coding standards.
</ul>

SonarQube is a powerful tool that contributes to the overall software development process by providing valuable insights into code quality. By integrating SonarQube into their workflows, development teams can continuously monitor and improve the quality of their codebases, resulting in more maintainable, secure, and efficient software applications.





