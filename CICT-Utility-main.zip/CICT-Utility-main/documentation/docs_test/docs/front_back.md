# 3. Frontend and Backend

<h1>Frontend</h1>

Designed and Developed on React.js which is one of the most popular Javascript Framwework for web-designs our frontend has 2 pages the login page for user login and the details page for the taking the user input.

<h4>Login Page</h4>

![placeholder](img/login.PNG)

Once the user has successfully entered the credentials a JWT token is generated and the user is logged in and redirected to the details page.

<h4>Details Page</h4>

![placeholder](img/front_ga.PNG)

![placeholder](img/front_jenkins.PNG)

The details page as you can see makes the user to enter few details and requirements:-

<ol>
<li><strong>Github Url:</strong> URL of the repository which has to be analyzed can be developer's repository or any other repository.
<li><strong>Branch Name:</strong> Which branch of the repository you want to scan.
<li><strong>Personel Access Token:</strong> As this is an organization project PAT is needed to access the repositories as following the Organization policies no one without PAT should be able to access any Github repository within the organization.
<li><strong>Language:</strong>Language of the repository.
<li><strong>Method:</strong>Which method the user wants Jenkins or Github Actions for the analysis and testing pipeline.
<li><strong>Linter:</strong>Which linter the user wants to validate the code in the repository.
<li><strong>Jenkins Username</strong> Jenkins Dashboard Username
<li><strong>Jenkins API Token</strong> Jenkins API Token
<li><strong>Credentials</strong> Jenkins API Token
</ol>

<h1>Backend</h1>

<h2>1. FOLDER STRUCTURE</h2>

The code works with a folder structure as follows:

![placeholder](img/folder.png)

<h3>2. PATHS</h3>

The backend revolves around four paths: backend path, parent path, workspace path. and repository path.

<ol>
 
<li>Backend path: Path of backend code
<li>Parent path: Path of application folder
<li>Workspace path: Path of workspace (created afterwards, repository is cloned here)
<li>Repository path: Path of cloned repository in workspace. Basically, just one level further in workspace path.

</ol>
 
 
Regular Expression matching: Regular Expression matches the repository link provided in the form rendered in the front-end, checking for standard git repository link patterns such as ".git" in end, "https://" in the beginning, etc.
 
Validated repository link is concatenated with the personal access token.

<h2>3. GITHUB OPERATONS:</h2>

<h3>3.1 CLONE </h3>

Working directory: Workspace Directory
Command: git clone --branch <branch> <url with token>
Purpose: To clone a particular pre-existing branch, <branch> from the repository.
 
Bottlenecks:
 
<ol>
 <li>Branch does not exist: The said branch is not available in the repository
 <li>Invalid Url: The url provided is incorrect
 <li>Invalid PAT: The personal access token provided is wrong, or does not have sufficient permissions
 <li>Git not installed: Git is not installed in the server running the backend code.
 <li>Path issues: Wrong workspace path because of compromised folder structure.

</ol>
Returns "Clone Failed!" message on terminal in server in any above case.

<h3>3.2 BRANCH LIST</h3>

Working directory: Workspace Directory
Command: git clone --branch <branch> <url with token>
Purpose: To clone a particular pre-existing branch, <branch> from the repository.
 
Bottlenecks:
 
<ol>
 <li>Invalid Url: The url provided is incorrect
 <li>Invalid PAT: The personal access token provided is wrong, or does not have sufficient permissions
 <li>Git not installed: Git is not installed in the server running the backend code.
 <li>Path issues: Wrong workspace path because of compromised folder structure.
 <li>Folder not under version control.

</ol>
Return "Git Branch List Failed!" message on terminal in server in any above case.
  
Note: Stores list of branches internally in case the available branches need to be displayed if a wrong branch is entered by the user.

<h3>3.3 ADD</h3>
Working Directory: Repository Directory
Command: git add .
Purpose: To add all the changes in the git version control folder, i.e. the cloned repository.
It checks for the method selected by the user. If the method is 1, it selects the jenkins file based on user's choice and copies it to the cloned repository. This copying procedure uses shutil library. If the selected method is 2, it selects the github actions file, creates a folder ".github" with a folder "workflows", and copies the file in it.
 
Bottlenecks:

<ul>
 
<li> Git not installed: Git is not installed in the server running the backend code.
<li> Path issues: Wrong workspace path because of compromised folder structure. Directory not created because of corrupt/compromised folder structure.
<li> File missing: The respective file for method selected is missing, or has wrong name/format.
<li>Permission Issues: Not permitted to copy from/to the locations.
<li>Folder not under version control.

 
 
<li>Returns "Source and destination represents the same file" if source and destinations points to same file.
<li>Returns "Permission denied" if inadequate permissions.
<li>Returns "Error - copy failed!" in other scenarios.
 
<li>Returns "Added" if git add successsful.
<li>Returns "Error - add failed!" if add unsuccessful.
 </ul> 
 
 
<h3>3.4 COMMIT</h3>
Working Directory: Repository Directory
Command: git commit -m <commit message>
Purpose: To commit the changes (uploads) made.
 
Bottlenecks:
 <ul>
<li> Git not installed: Git is not installed in the server running the backend code.
<li> Folder not under version control.
 </ul>
 
 
<h3>3.5 REMOTE URL VIEW AND ADD</h3>
Working Directory: Repository Directory
Command: git remote -v or git remote add origin url
Purpose: To view and add remote origin url
 
Bottlenecks:
 <ul>
<li> Git not installed: Git is not installed in the server running the backend code.
<li> Folder not under version control.
<li> Invalid URL
 </ul>
Returns "Remote Add Failed!" if url is added unsuccessfully.
 
 

 
<h3>3.6 CHECKOUT</h3>
Working Directory: Repository Directory
Command: git checkout -b <branch_new>
Purpose: To create a new branch, with the name <branch>+"_new" and set it for git push.
 
Bottlenecks:
 <ul>
<li> Git not installed: Git is not installed in the server running the backend code.
<li> Folder not under version control.
<li> Branch creation is failed due to some reason.
 </ul>
Returns "Checkout failed!" if new branch cannot be created or because of some other issue.
 
 
 
<h3>3.7 PUSH</h3>
Working Directory: Repository Directory
Command: git push -f origin <branch_new>
Purpose: To create a new branch in the github remote repository and push the new content.
 
Bottlenecks:
<ul> 
<li> Git not installed: Git is not installed in the server running the backend code.
<li> Folder not under version control.
<li> Branch does not exists: Due to previous failure in branch creation, branch may not exist.
<li> Remote Url is wrong. Wrong origin set.
</ul> 
Returns "Error - push failed!" if git push is failed.
 
 
 
<h3>3.8 BRANCH STATUSES</h3>
 

Working Directory updated to backend path before further operations. Git command requires cloned repository path, i.e. Repository Path, as it is under version control. The version control configurations are specified in the .git file, that is formed when a repository is cloned. Here, the repository is cloned locally on the server running the backend code.

 
 
<h3> 4 JENKINS OPERATIONS:</h3>
 
If method is jenkins (1), we call jenkins operations for job creation, configuration, triggers and results. These jenkins calls are made through web requests using the requests library. Authentication can be provided using ssl certificates, firewall configurations etc. 
 
Jenkins commands are independent of the working directories since they are based on web requests. 
 
<h3>4.1 PARAMETERS</h3>
Jenkins commands require some pre-defined parameters, that are not subjected to change. Since this framework is for internal optum use, some parameters that will remain constant are:
 <ul>
<li> Optum Jenkins URL => jenkins_url
<li> A security credential in jenkins, that grants access to github optum repository. A credential, especially for github access and testing purposes, would be useful to have. => credential
<li> Username of jenkins. => username
<li> Access token of jenkins as password. => password
<li> SSL certificate (optional)
 </ul>
For authentication, variable auth (a tuple) is used. 
auth = (username of jenkins account, access token of jenkins account)
auth = (username, password)
 
 
 
<h3>4.2 JOB CONFIGURATION:</h3>
Job Configuration: Any testing jobs would be created using specific configurations. These configurations are passed as an XML file during job creation.
 <ul>
Parameters needed for multibranch pipeline job:
<li> Github repository url (gurl)
<li> Jenkins github access credential id (cred)
<li> File path of jenkinsfile in repository (spath)
<li> Branch name (branch)
<li> Job Name (job_name)
<li> Jenkins job id (id) - This can be any random id.
 </ul>
 
 
 
<h3>4.3 CHECK FOR PULL REQUESTS</h3>
This is used to check for any open pull requests in the git repository. Pull requests are expected to be opened by the user/developer using the tool. If any pull requests contain the branch created in 6th stage of git operations, jenkins operations are triggered.
 
Pull requests keeps checking for pull requests with the newly created branch, and as soon as it gets it, it triggers jenkins operations.
 
Pull request requests check requires some parameters such as:
 <ul>
<li> owner: Owner of the repository
<li> repo: Repository name
<li> token: Personal access token of the repository
 
 
API URL for github pull requests fetching: 
<li>'https://api.github.com/repos/{owner}/{repo}/pulls'
<li> 'https://api.github.com/repos/{owner}/{repo}/pulls/{pull_request_number}'
 </ul>
Uses web requests with header,
headers = {'Authorization': f'token {token}'}
for fetching the results
 
def get_pull_requests_with_branches(owner, repo)

 
 
<h3>4.4 CREATE JOB</h3>
Assuming we are creating a jenkins job in a folder,
 
Type: Post
URL: jenkins_url/job/<folder_name>/createItem
Headers: {'Content-Type':'application/xml'}
auth = (username, password)
params: {'name': job_name}
data = configuration
verify = False //For SSL verification
 
Response codes can be used to check if there is an issue.
 
Bottlenecks:
 <ul>
<li> Invalid Jenkins URL
<li> Jenkins URL not accessible
<li> Invalid Jenkins token/jenkins username
<li> Invalid Jenkins-Github Credential
<li> Invalid Job Configuration
<li> Plugin Issues
<li> Repository may not have jenkinsfile/wrong path
 </ul>
 
CREATES A JOB IN JENKINS.
 
 
<h3>4.5 BUILD JOB</h3>
Type: Post
URL: jenkins_url/job/<folder_name>/job<job_name>/build
auth = (username, password)
verify = False //For SSL verification
 
Response codes can be used to check if there is an issue.
 
Bottlenecks:
 <ul>
<li> Invalid Jenkins URL
<li> Jenkins URL not accessible
<li> Invalid Jenkins token/jenkins username
<li> Invalid Jenkins-Github Credential
<li> Invalid Job Configuration
<li> Plugin Issues
<li> Repository may not have jenkinsfile/wrong path
 </ul>
 
BUILDS/TRIGGERS THE JOB CREATED IN JENKINS
 
 

 
<h3>4.6 SCANNING BUILD JOB OUTPUTS</h3>
Type: Post
URL: jenkins_url/job/<folder_name><job><job_name>/indexing/consoleText
auth = (username, password)
verify = False //For SSL verification
 
Response codes can be used to check if there is an issue.
 
 
Bottlenecks:
 <ul>
<li> Invalid Jenkins URL
<li> Jenkins URL not accessible
<li> Invalid Jenkins token/jenkins username
<li> Invalid Jenkins-Github Credential
<li> Invalid Job Configuration
<li> Plugin Issues
<li> Repository may not have jenkinsfile/wrong path
 </ul>
 
FETCHES THE BUILD RESULT


 

 
