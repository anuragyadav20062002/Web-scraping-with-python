# 2. Architecture

![placeholder](img/architecture.png)

The whole architecture is mainly divided into 5 sub categories and all the steps are happening in real time:

1. <p><strong>User Input:</strong> This is the foremost step where necessary information is taken from the user like repository url, Personel Access Token(PAT),Language of the project,Method for analysis-Jenkins or Github Actions, Linter(For Code Validation), Gate Level(For Sonarqube). This information is required for further procesing and functionalities.</p>

2. <p><strong>Backend API Integration:</strong> In this step the data which is taken by the user is processed and user repository is cloned and then several configuration files are generated and added into the cloned repository like Pull request template,vitals.yaml, Danger.js and Danger.yaml file for Danger bot which is responsible for Pull request feedback,JenkinsFile/Github_actions file for pipeline, then linter file, labeller etc.</p>

3. <p><strong>Pipeline Buildup:</strong>According to the method selected by the usre either Jenkins or github actions a pipeline is build either or jenkins or github containing unit tests, integrations, linter and sonar analysis.  </p>

4. <p><strong>Github Actions:</strong>There are many other workflows apart from the maine pipeline like pull request validator for checking that is the pull request template is filled correctly, labeller for automatic label generation, danger bot fot pull request feedback, code coverage for report generation which all run on github actions.</p>



