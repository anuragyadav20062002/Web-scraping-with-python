# 5. Setting Up

<ol>

<li>Install Virtual Enviornment
<ul>
<li>pip install virtualenv
<li>python -m venv <virtual-environment-name>
</ul>
<li>Install frontend dependencies
<ul>
<li>cd client
<li>npm install
<li>npm start
</ul>
<li>Install python dependencies
<ul>
<li>Open another terminal
<li>cd backend
<li>pip install -r requirement.txt
<li>uvicorn main:app --reload
</ul>
</ol>



<h3>Configurations –</h3>

<ol>
<li>UI Constraints-

Branch name cannot be main, master, main-green etc
Url should end with .git

<li>Secrets which need to be added in repository
<ul>
	<li>-SONAR_TOKEN - 092c919905283a6d35ff1abe2128fc52e48a6156
	<li>-GTTHUB_TOKEN- PAT
</ul>
 GTTHUB_TOKEN is the Personnel Access Token, 
 also GTTHUB_TOKEN is not a typo because 
 GitHub doesn’t allow secret with name GITHUB_TOKEN

 <li> 

Sonar projectKey in the vitals.yaml should match with the projectKey in the sonar-project.properties generated from backend
 </ol>
