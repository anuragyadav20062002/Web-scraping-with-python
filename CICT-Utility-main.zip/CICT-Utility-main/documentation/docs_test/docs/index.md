# 1. Overview
<h3>Problem Statement</h3>
Manual code reviews and lack of automated validation processes during software development led to time-consuming and error-prone practices. There is a need to develop a CI-CT framework that enforces coding standards, best practices, verification & security vulnerabilities and validate code quality. Reducing manual effort and improving development efficiency
<h3>Solution</h3>
This project is an end-to-end tool that will validate the code with standards as per specific language and ensures quality of the code
<br>

![placeholder](img/workflow.png)
